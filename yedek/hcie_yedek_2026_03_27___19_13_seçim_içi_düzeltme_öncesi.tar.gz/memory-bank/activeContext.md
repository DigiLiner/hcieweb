# Active Context

## Current Focus
Migrating the backend infrastructure from Electron to Tauri v2 for improved performance, smaller binary sizes, and modern systems integration, while keeping the web-first frontend completely intact.

## Recent Changes
- **Backend Migration (Electron to Tauri):**
    - Replaced `electron` and `electron-builder` with `@tauri-apps/cli` and initialized Tauri project configuration (`src-tauri`).
    - Implemented a custom lightweight copy script (`build:tauri`) to feed the Tauri frontend distribution.
    - Replaced legacy IPC files (`main.js`, `preload.js`) with global Tauri plugins `dialog` and `fs`, safely injected using `withGlobalTauri`.
    - Rewrote frontend API detection wrapper in `renderer.js` to map Electron API usage seamlessly to native Tauri capabilities.
- **Selection Tools refined:**
    - **Marching Ants:** Separated into `selectionBorder` (committed) and `selectionPreviewBorder` (live). This prevents the "disappearing ants" bug during drawing/new selection and allows for multi-path rendering.
    - **Move Selection Tool:** Explicit tool to move only the marching ants mask.
    - **Move Content Tool:** New tool that "picks up" the selected pixels from the active layer, allows dragging them, and drops them on mouseup. Implemented via `floatingContent` cache and `finalizeMoveContent`.
    - **Polygon Selection Tool Refined:** Fixed drawing persistence (rubber band), movement detection (click inside), and state clearing on Escape/deselect.
- **Electron App Packaging:**
  - Successful creation of `.AppImage` and `.deb` executables for Linux.
  - Optimized build configuration to exclude development source files and include only runtime assets.
  - Resolved build-time metadata requirements (maintainer/author).
    - **Optimized Merging:** `combineMask` now uses Canvas `globalCompositeOperation` (add, subtract, intersect) for sub-pixel accuracy and high performance.
- **Keyboard Shortcuts:** Implemented global listeners for `Ctrl+C` (Copy), `Ctrl+V` (Paste), `Ctrl+X` (Cut), `Ctrl+A` (Select All), `Ctrl+D` (Deselect), `Ctrl+Shift+I` (Invert), `Ctrl+Z/Y` (Undo/Redo).
- **Clipboard Fix:** Resolved bug in `pasteSelection` where `layer_class` was initialized with a boolean instead of numeric dimensions.
- **Tool Defaults:** Shared Size (pen_width) default 2, min 1, max 100 in [global.js](global.js). Spray radius default 100 max 600, density default 100 max 300. App opens with these defaults; tool change does not reset sliders. Vector edit: options bar Size/Opacity sync to selected shape via `vectorShapeSelectionChanged` in [options-bar.js](options-bar.js).
- **Vector Select + Properties Panel:** Vector Select tool shows "Select a shape to edit" until a shape is selected; then panel shows only that shape type’s controls (line/rect/circle/ellipse → Hardness; roundrect → Hardness + Corner Radius). State via `window.vectorSelection` and `vectorShapeSelectionChanged` ([apps/vector_tools.js](apps/vector_tools.js), [properties-panel.js](properties-panel.js) `VECTOR_SHAPE_PROPS`).
- **Vector Hardness:** Hardness now affects vector shapes (line, rect, circle, ellipse, roundrect). In [layers.js](layers.js) `drawShapesToCtx`, each shape's `style.hardness` is applied via `ctx.shadowBlur` for soft edges (1 = sharp, 0 = soft). Hardness is stored in `shape.style` and synced to/from the Properties panel.
- **Properties Panel vs Options Bar:** Panel no longer shows Opacity or Size (pen_opacity, pen_width); those are only in the top options bar. Panel shows only "extra" tool properties (e.g. Hardness, Flow, Tolerance, Corner Radius, Font). When a tool has no such props, panel shows "No extra options" ([properties-panel.js](properties-panel.js), `TOOLBAR_ONLY_PROPS` filter).
- **Accessibility (Form Labels):** Completed. Toolbar Opacity and Size sliders in `index.html` now use `<label for="opacitySlider">` and `<label for="sizeSlider">`; linter no longer reports label errors for those inputs.
- **Vector Tool Enhancements:**
    - **Corner Radius:** Full support for `cornerRadius` in Rounded Rectangles, synced between `vector_tools.js`, `global.js`, and the Properties Panel.
    - **Property Sync:** Selection of a vector shape now populates the sidebar with its actual style properties (width, color, opacity, etc.), allowing for immediate editing.
    - **New Icon:** Added a high-quality Lucide SVG icon (`square-dashed-mouse-pointer`) for the Vector Select tool in the `ie_color` theme.
- **Menu & Filtering System:**
    - **Menu Migration:** Consolidated and mirrored Electron's "Image" and "Filter" menus in the web UI. Added icons to all menu entries for a premium feel.
    - **Filter Logic:** Restored and expanded `filters.js` to handle Grayscale, Sepia, Negative, Blur, and Mosaic via standard `CanvasRenderingContext2D` operations.
- **Internal Tools:**
    - **Backup Script (`yedekal.py`):** Updated to support command-line arguments and interactive comments. Comments are automatically sanitized and appended to the backup filename for better version tracking.
- **Vector Circle Resize Fixed:**
    - Modified `onResizeMove` in `apps/vector_tools.js` to scale Radius proportionally on diagonal or axes drag rather than independently on coordinates to avoid lagging Feedback Loops.
- **Eraser tool fixed:**
    - Modified `on_canvas_mouse_down` in `drawing_canvas.js` to copy the active layer to `tempCtx` for the Eraser tool, allowing `drawEraser` to work on existing content.
    - Modified `renderLayers` in `layers.js` to avoid rendering the permanent active layer content on top while the Eraser is drawing.
    - Modified `finishDrawing` in `drawing_canvas.js` to clear the active layer context before committing `tempCanvas` so erased transparency is applied.
- **UI Architecture:**
    - **Dynamic Theme Support:** Implemented `@media (prefers-color-scheme: light)` and a centralized CSS variable system in `styles.css`.
    - **Unified Styling:** Refactored all component CSS files to consume shared variables, ensuring the entire app (including menus and dialogs) adapts to dark/light mode instantly.
    - **Sidebar Tabs:** Resolved z-index and visibility conflicts between History and Swatches panes.
    - **Event Bus:** Extended the custom event bus to handle `syncOpacity`, `cornerRadiusChanged`, and `hardnessChanged` for real-time UI/Canvas updates.
- **Electron App Packaging:**
  - Configured `electron-builder` in `package.json` for Linux executables.
  - Added support for `AppImage` and `.deb` targets.
  - Optimized file inclusion to reduce bundle size (included only `.js`, `.html`, `.css`, and essential assets).
  - Created persistent `build/` directory with `icon.png`.
  - Added required metadata (author, maintainer) to `package.json` for Linux build compatibility.

## Active Issues (Resolved)
1. **Vector Properties Panel Invisibility:** Fixed by mapping tools to global configs in `global.js`.
2. **Opacity Non-functional:** Fixed by adding `pen_opacity` to tool configs and handling the `syncOpacity` event.
3. **Redundant Filter Menus:** Consolidated into a single, comprehensive menu matching the Electron version.
4. **Flood Fill Bugs:** Fixed layer erasure bug and implemented proper vector/composite sampling.
5. **TypeScript Type Mismatch (src/io/api.ts):** Resolved `Uint8Array<ArrayBufferLike>` to `BlobPart` error in `Blob` constructor via explicit casting.
6. **Missing Background Checker:** Corrected `build:tauri` script in `package.json` to copy `*.png` and other images to `tauri-dist`.

## Next Steps
- Replace remaining `alert()`/`confirm()` with `DialogHandler`.
- Implement placeholder filters in `filters.js` (Sharpen, Emboss, etc.).
- Robust testing of Move Selection pixel data (currently only moves the mask, not the pixels unless Cut/Paste is used).

