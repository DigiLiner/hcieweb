import { g, layers } from '../core/globals';
import { historyManager, DrawAction } from '../core/history';
import { renderLayers, updateLayerPanel } from '../canvas/layers';
import { api } from '../io/api';
import { ProjectIO } from '../io/project-io';
import { newDocument } from '../core/document';
import * as filters from '../canvas/filters';

/**
 * Menu Handlers
 * This module provides global functions that are called by onclick attributes in index.html.
 * It bridges the modular TypeScript codebase with the legacy HTML-based UI.
 */

// --- File Operations ---

export async function handleSaveAsFile() {
    try {
        const content = await ProjectIO.saveProject();
        const savedPath = await api.saveFile(content, g.filepath, true, 'hcie');
        if (savedPath) {
            g.filepath = savedPath;
            const el = document.getElementById('filePath');
            if (el) el.innerText = savedPath;
        }
    } catch (err) {
        console.error('Save As failed:', err);
    }
}

export async function handleExportFile() {
    try {
        const activeLayer = layers[g.activeLayerIndex];
        if (!activeLayer) return;
        
        const dataURL = (activeLayer.canvas as HTMLCanvasElement).toDataURL('image/png');
        await api.saveFile(dataURL, g.filepath, true, 'png');
    } catch (err) {
        console.error('Export failed:', err);
    }
}

// --- Edit Operations ---

export function undoImage() {
    historyManager.undo();
}

export function redoImage() {
    historyManager.redo();
}

export function clearCanvas() {
    const activeLayer = layers[g.activeLayerIndex];
    if (!activeLayer || activeLayer.locked) return;

    const ctx = activeLayer.ctx as CanvasRenderingContext2D;
    const oldData = ctx.getImageData(0, 0, g.image_width, g.image_height);
    
    ctx.clearRect(0, 0, g.image_width, g.image_height);
    
    const newData = ctx.getImageData(0, 0, g.image_width, g.image_height);
    historyManager.push(new DrawAction(g.activeLayerIndex, oldData, newData));
    
    renderLayers();
    updateLayerPanel();
}

// --- Filter Operations ---

export function applyFilter(type: string) {
    const activeLayer = layers[g.activeLayerIndex];
    if (!activeLayer || activeLayer.locked) return;

    const ctx = activeLayer.ctx as CanvasRenderingContext2D;
    const imageData = ctx.getImageData(0, 0, g.image_width, g.image_height);

    switch (type) {
        case 'negative':
        case 'invert':
            filters.applyNegative(imageData);
            break;
        case 'grayscale':
            filters.applyGrayscale(imageData);
            break;
        case 'sepia':
            filters.applySepia(imageData);
            break;
        case 'blur':
            // Using default radius from globals
            const blurred = filters.applyBoxBlur(imageData, g.blur_radius);
            ctx.putImageData(blurred, 0, 0);
            break;
        case 'mosaic':
            const pixelated = filters.applyMosaic(imageData, g.mosaic_block_size);
            ctx.putImageData(pixelated, 0, 0);
            break;
        default:
            console.warn('Unknown filter type:', type);
            return;
    }

    if (type !== 'blur' && type !== 'mosaic') {
        ctx.putImageData(imageData, 0, 0);
    }

    renderLayers();
    updateLayerPanel();
    // TODO: Add to history
}

// --- View Operations ---

export function zoomIn() {
    if ((window as any).zoomIn) {
        (window as any).zoomIn(null);
    }
}

export function zoomOut() {
    if ((window as any).zoomOut) {
        (window as any).zoomOut(null);
    }
}

// --- New Image Dialog ---

export function closeNewImageDialog() {
    const modal = document.getElementById('newImageModal');
    if (modal) modal.style.display = 'none';
}

export function openNewImageDialog() {
     const modal = document.getElementById('newImageModal');
    if (modal) modal.style.display = 'block';
}

export function createNewImage() {
    const width = parseInt((document.getElementById('newWidth') as HTMLInputElement).value);
    const height = parseInt((document.getElementById('newHeight') as HTMLInputElement).value);
    const name = "Untitled"; 
    
    newDocument(name, width, height);
    closeNewImageDialog();
}

// Expose to window
if (typeof window !== 'undefined') {
    Object.assign(window, {
        handleSaveAsFile,
        handleExportFile,
        undoImage,
        redoImage,
        clearCanvas,
        applyFilter,
        zoomIn,
        zoomOut,
        closeNewImageDialog,
        openNewImageDialog,
        createNewImage
    });
}
