import { g } from '../core/globals';

/**
 * Core Painting Tools
 * Provides basic drawing routines for pen, brush, eraser, and shapes.
 * Ported from legacy tools.js.
 */

export function drawPen(_e: MouseEvent, ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    ctx.lineCap = g.pen_cap || "round";
    ctx.lineJoin = g.pen_join || "round";
    
    ctx.moveTo(g.startX, g.startY);
    ctx.lineTo(g.pX, g.pY);
    ctx.stroke();
    
    g.startX = g.pX;
    g.startY = g.pY;
}

export function drawLine(_e: MouseEvent, ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    ctx.lineCap = g.pen_cap || "round";
    ctx.lineJoin = g.pen_join || "round";
    
    ctx.moveTo(g.startX, g.startY);
    ctx.lineTo(g.pX, g.pY);
    ctx.stroke();
    ctx.closePath();
}

export function drawRect(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number): void {
    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    
    const width = x2 - x1;
    const height = y2 - y1;
    ctx.rect(x1, y1, width, height);
    ctx.stroke();
    ctx.closePath();
}

export function drawCircle(_e: MouseEvent, ctx: CanvasRenderingContext2D): void {
    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    
    const radius = Math.hypot(g.pX - g.startX, g.pY - g.startY);
    ctx.arc(g.startX, g.startY, radius, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.closePath();
}

export function drawBrush(ctx: CanvasRenderingContext2D, x: number, y: number): void {
    const size = g.pen_width;
    const hardness = (g.brush_hardness !== undefined) ? g.brush_hardness : 0.5;
    const color = g.pen_color;
    const flow = (g.brush_flow !== undefined) ? g.brush_flow : 1.0;

    ctx.save();
    ctx.globalAlpha = (g.pen_opacity || 1.0) * flow;

    const radius = size / 2;
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    
    // Convert hex to RGBA for the gradient to support alpha
    const rgba = hexToRgba(color);
    const centerColor = `rgba(${rgba.r}, ${rgba.g}, ${rgba.b}, 1)`;
    const edgeColor = `rgba(${rgba.r}, ${rgba.g}, ${rgba.b}, 0)`;

    gradient.addColorStop(0, centerColor);
    if (hardness > 0) {
        gradient.addColorStop(Math.min(0.99, hardness), centerColor);
    }
    gradient.addColorStop(1.0, edgeColor);

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

export function drawEraser(ctx: CanvasRenderingContext2D, startX: number, startY: number, endX: number, endY: number): void {
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    
    const length = Math.hypot(endX - startX, endY - startY);
    let numSteps = 1;
    if (length >= 1) {
        const spacing = g.pen_width / 4.0; // Tighter spacing for smoother erasing
        numSteps = Math.floor(length / spacing) + 1;
    }
    
    for (let i = 0; i <= numSteps; i++) {
        const t = i / numSteps;
        const currentX = startX * (1.0 - t) + endX * t;
        const currentY = startY * (1.0 - t) + endY * t;
        
        const size = g.pen_width;
        const hardness = (g.brush_hardness !== undefined) ? g.brush_hardness : 0.8;
        const opacity = g.pen_opacity || 1.0;
        
        const radius = size / 2;
        const gradient = ctx.createRadialGradient(currentX, currentY, 0, currentX, currentY, radius);
        
        const centerColor = `rgba(0, 0, 0, ${opacity})`;
        const edgeColor = 'rgba(0, 0, 0, 0)';
        
        gradient.addColorStop(0, centerColor);
        if (hardness > 0) {
            gradient.addColorStop(Math.min(0.99, hardness), centerColor);
        }
        gradient.addColorStop(1.0, edgeColor);
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(currentX, currentY, radius, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

export function drawRoundedRect(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number): void {
    const x = Math.min(x1, x2);
    const y = Math.min(y1, y2);
    const width = Math.abs(x2 - x1);
    const height = Math.abs(y2 - y1);
    
    let radius = g.round_rect_corner_radius || 10;
    if (radius > width / 2) radius = width / 2;
    if (radius > height / 2) radius = height / 2;

    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    ctx.lineJoin = g.pen_join || "round";

    if ((ctx as any).roundRect) {
        (ctx as any).roundRect(x, y, width, height, radius);
    } else {
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        ctx.lineTo(x + radius, y + height);
        ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
    }

    ctx.closePath();
    ctx.stroke();
}

export function drawEllipse(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number): void {
    const centerX = (x1 + x2) / 2;
    const centerY = (y1 + y2) / 2;
    const radiusX = Math.abs(x2 - x1) / 2;
    const radiusY = Math.abs(y2 - y1) / 2;
    
    ctx.beginPath();
    ctx.lineWidth = g.pen_width;
    ctx.strokeStyle = g.pen_color;
    ctx.globalAlpha = g.pen_opacity || 1.0;
    
    ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.closePath();
}

// ─── Helpers ──────────────────────────────────────────────

function hexToRgba(hex: string): { r: number, g: number, b: number } {
    let r = 0, g = 0, b = 0;
    hex = hex.replace('#', '');
    if (hex.length === 3) {
        r = parseInt(hex[0] + hex[0], 16);
        g = parseInt(hex[1] + hex[1], 16);
        b = parseInt(hex[2] + hex[2], 16);
    } else if (hex.length === 6) {
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);
    }
    return { r, g, b };
}

// Global exposure for legacy interop
(window as any).drawPen = drawPen;
(window as any).drawLine = drawLine;
(window as any).drawRect = drawRect;
(window as any).drawCircle = drawCircle;
(window as any).drawBrush = drawBrush;
(window as any).drawEraser = drawEraser;
(window as any).drawRoundedRect = drawRoundedRect;
(window as any).drawEllipse = drawEllipse;
