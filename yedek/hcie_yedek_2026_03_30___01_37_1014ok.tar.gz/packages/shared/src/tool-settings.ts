import { g } from '@hcie/core';

/**
 * Interface representing all persistable tool settings.
 */
export interface ToolSettings {
  pen: { size: number; opacity: number; };
  brush: { size: number; opacity: number; hardness: number; };
  eraser: { size: number; opacity: number; hardness: number; };
  spray: { radius: number; density: number; opacity: number; };
  fill: { tolerance: number; opacity: number; };
}

/**
 * Default values for tool settings.
 */
export const DEFAULT_TOOL_SETTINGS: ToolSettings = {
  pen: { size: 2, opacity: 100 },
  brush: { size: 10, opacity: 100, hardness: 80 },
  eraser: { size: 15, opacity: 100, hardness: 50 },
  spray: { radius: 20, density: 30, opacity: 100 },
  fill: { tolerance: 32, opacity: 100 },
};

const STORAGE_KEY = 'hcie-tool-settings-v2';

let globalSettings: ToolSettings | null = null;

/**
 * Loads tool settings from localStorage, merging with defaults.
 */
export function loadToolSettings(): ToolSettings {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    globalSettings = JSON.parse(JSON.stringify(DEFAULT_TOOL_SETTINGS));
  } else {
    try {
      const parsed = JSON.parse(stored);
      // Deep merge with defaults to handle versioning/new keys
      globalSettings = {
        pen: { ...DEFAULT_TOOL_SETTINGS.pen, ...parsed.pen },
        brush: { ...DEFAULT_TOOL_SETTINGS.brush, ...parsed.brush },
        eraser: { ...DEFAULT_TOOL_SETTINGS.eraser, ...parsed.eraser },
        spray: { ...DEFAULT_TOOL_SETTINGS.spray, ...parsed.spray },
        fill: { ...DEFAULT_TOOL_SETTINGS.fill, ...parsed.fill },
      };
    } catch (e) {
      console.error('[SETTINGS] Failed to parse tool settings, using defaults', e);
      globalSettings = JSON.parse(JSON.stringify(DEFAULT_TOOL_SETTINGS));
    }
  }
  
  // Apply to core global state g for backward compatibility
  syncToCoreG();
  
  // Dispatch event for UI components to refresh
  window.dispatchEvent(new CustomEvent('settingsRestored'));
  
  return globalSettings!;
}

/**
 * Saves current tool settings to localStorage.
 * @param settings Optional partial settings to update before saving.
 */
export function saveToolSettings(settings?: Partial<ToolSettings>) {
  if (!globalSettings) {
    loadToolSettings();
  }
  
  if (settings) {
    // Deep update
    Object.keys(settings).forEach((key) => {
      const toolKey = key as keyof ToolSettings;
      if (globalSettings && settings[toolKey]) {
        globalSettings[toolKey] = { ...globalSettings[toolKey], ...settings[toolKey] } as any;
      }
    });
  } else {
    // Sync FROM core G before saving to ensure we have manual UI changes
    syncFromCoreG();
  }

  localStorage.setItem(STORAGE_KEY, JSON.stringify(globalSettings));
  
  // Ensure G is up to date after merge/save
  syncToCoreG();
  
  console.log('[SETTINGS] Tool settings saved');
}

/**
 * Returns the current in-memory settings singleton.
 */
export function getGlobalSettings(): ToolSettings {
  if (!globalSettings) {
    return loadToolSettings();
  }
  return globalSettings;
}

/**
 * Syncs the structured globalSettings to the flat core 'g' object.
 */
function syncToCoreG() {
  if (!globalSettings) return;
  
  const toolId = g.current_tool?.id;
  if (toolId) {
    restoreSettingsForTool(toolId);
  } else {
    // Fallback: sync pen defaults
    g.pen_width = globalSettings.pen.size;
    g.pen_opacity = globalSettings.pen.opacity / 100;
  }
}

/**
 * Restores tool-specific settings from the global settings object to the active state 'g'.
 * @param toolId The ID of the tool (e.g., 'btn-pen').
 */
export function restoreSettingsForTool(toolId: string) {
  if (!globalSettings) loadToolSettings();
  
  console.log(`[SETTINGS] Restoring settings for ${toolId}`);
  
  if (toolId === 'btn-pen') {
    g.pen_width = globalSettings!.pen.size;
    g.pen_opacity = globalSettings!.pen.opacity / 100;
  } else if (toolId === 'btn-brush') {
    g.pen_width = globalSettings!.brush.size;
    g.brush_hardness = globalSettings!.brush.hardness / 100;
    g.pen_opacity = globalSettings!.brush.opacity / 100;
  } else if (toolId === 'btn-eraser') {
    g.pen_width = globalSettings!.eraser.size;
    g.brush_hardness = globalSettings!.eraser.hardness / 100;
    g.pen_opacity = globalSettings!.eraser.opacity / 100;
  } else if (toolId === 'btn-spray') {
    g.spray_radius = globalSettings!.spray.radius;
    g.spray_density = globalSettings!.spray.density;
    g.pen_opacity = globalSettings!.spray.opacity / 100;
  } else if (toolId === 'btn-flood-fill') {
    g.fill_tolerance = globalSettings!.fill.tolerance;
    g.pen_opacity = globalSettings!.fill.opacity / 100;
  }
}

/**
 * Syncs from flat core 'g' object back to structured globalSettings.
 */
function syncFromCoreG() {
  if (!globalSettings) return;
  
  // We use current_tool to know which structured bucket to update?
  // Or just update EVERYTHING from G's current state.
  // G reflects the "active" parameters.
  
  const toolId = g.current_tool?.id;
  
  if (toolId === 'btn-pen') {
    globalSettings.pen.size = g.pen_width;
    globalSettings.pen.opacity = Math.round(g.pen_opacity * 100);
  } else if (toolId === 'btn-brush') {
    globalSettings.brush.size = g.pen_width; // G uses pen_width for brush size too usually
    globalSettings.brush.hardness = Math.round(g.brush_hardness * 100);
    globalSettings.brush.opacity = Math.round(g.pen_opacity * 100);
  } else if (toolId === 'btn-eraser') {
    globalSettings.eraser.size = g.pen_width;
    globalSettings.eraser.hardness = Math.round(g.brush_hardness * 100);
    globalSettings.eraser.opacity = Math.round(g.pen_opacity * 100);
  } else if (toolId === 'btn-spray') {
    globalSettings.spray.radius = g.spray_radius;
    globalSettings.spray.density = g.spray_density;
    globalSettings.spray.opacity = Math.round(g.pen_opacity * 100);
  } else if (toolId === 'btn-flood-fill') {
    globalSettings.fill.tolerance = g.fill_tolerance;
    globalSettings.fill.opacity = Math.round(g.pen_opacity * 100);
  }
}
