import { loadToolSettings } from '@hcie/shared';
import * as coreModule from '@hcie/core';
import * as canvasUIModule from '@hcie/canvas-ui';
import * as toolsModule from '@hcie/tools';
import * as ioModule from '@hcie/io';
import * as uiComponentsModule from './index';
import { setupWindowControls } from './window-controls';
import { setupThemeToggle } from './theme';
import { initializeArtisticBrushes } from './artistic-brushes';

/**
 * UIController
 * Orchestrates the initialization of all UI components and legacy global exposures.
 */
export class UIController {
    /**
     * Initializes the application UI and exposes necessary modules to the window object
     * for legacy compatibility.
     */
    public async init() {
        console.log("[UIController] Initializing Application...");

        // 1. Load saved tool settings before UI components initialize
        try {
            loadToolSettings();
        } catch (e) {
            console.warn("[UIController] Failed to load tool settings:", e);
        }

        // 2. Expose modules to window for legacy compatibility
        this.exposeModules();

        // 3. Perform specific initializations
        this.runInitializers();

        // 4. Setup Custom Titlebar Controls (Tauri/Web)
        await setupWindowControls();

        // 5. Setup Theme Toggle
        setupThemeToggle();

        // 6. Initialize Artistic Brushes panel logic
        initializeArtisticBrushes();

        console.log("[UIController] All Modules (Core, Tools, UI) Initialized");
    }

    private exposeModules() {
        const w = window as any;
        console.log("[UIController] Exposing modules to window for legacy support...");

        // Grouping exposures to mimic src/main.ts behavior
        Object.assign(w, coreModule);
        Object.assign(w, canvasUIModule);
        Object.assign(w, toolsModule);
        Object.assign(w, ioModule);
        Object.assign(w, uiComponentsModule);

        // Note: src/main.ts had some redundant assignments, we simplified it here
        // by assigning the full modules.
    }

    private runInitializers() {
        const w = window as any;

        if (typeof w.initializeColorBox === 'function') {
            console.log("[UIController] Initializing ColorBox...");
            w.initializeColorBox();
        }

        if (typeof w.initPanels === 'function') {
            console.log("[UIController] Initializing Panels...");
            w.initPanels();
        }

        if (typeof w.initializePropertiesPanel === 'function') {
            console.log("[UIController] Initializing Properties Panel...");
            w.initializePropertiesPanel();
        }

        if (typeof w.initializeMenuBar === 'function') {
            console.log("[UIController] Initializing Menu Bar...");
            w.initializeMenuBar();
        }
        
        if (typeof w.initializeTabs === 'function') {
            console.log("[UIController] Initializing Tabs...");
            w.initializeTabs();
        }
    }
}
