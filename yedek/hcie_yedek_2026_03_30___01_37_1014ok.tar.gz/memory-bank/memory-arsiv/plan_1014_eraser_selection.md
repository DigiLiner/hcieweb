# Plan #1013 – Restrict Eraser to Selection

The user reports that the Eraser tool is erasing pixels outside the current selection, but it should be restricted only to the selection area.

## Current Behavior (Broken for Selection)
1. `on_canvas_mouse_down`: If Eraser, copy the entire active layer to `tempCtx`.
2. `drawEraser`: Subtractive brush using `destination-out` on `tempCtx`.
3. `finishDrawing`:
   - `applySelectionMaskToCtx`: Applies `destination-in` to `tempCtx`. Everything outside selection is cleared.
   - `activeLayer.ctx.clearRect`: The **entire layer** is cleared.
   - `activeLayer.ctx.drawImage(tempCanvas)`: The masked contents of `tempCanvas` are drawn back onto the layer.
   - **Result**: Everything outside the selection mask on the active layer is **effectively deleted**, as it was cleared and not copied back from `tempCanvas`.

## Proposed Fix: Subtractive Brush Strategy
Refactor the eraser to work as a "masking brush" that is only subtracted from the layer at the end.

### 1. `packages/tools/src/painting_tools.ts`
- Modify `drawEraser` to use `source-over` instead of `destination-out`.
- It will draw "erasure strokes" (mask) onto an empty `tempCtx`.

### 2. `packages/canvas-ui/src/drawing_canvas.ts`
- `on_canvas_mouse_down`: Remove the special case that copies the layer to `tempCtx` for Eraser.
- `finishDrawing`:
  - `applySelectionMaskToCtx` is already called. It will mask the eraser strokes to the selection.
  - When committing Eraser:
    - Do **NOT** `clearRect()` the whole layer.
    - Set `globalCompositeOperation = 'destination-out'` on the active layer's context.
    - `drawImage(tempCanvas)` to subtract the strokes.

### 3. `packages/canvas-ui/src/layers.ts`
- `renderLayers`:
  - Update the "Composition" section (line 187) to draw the layer pixels EVEN if using the eraser.
  - Update the "Live Preview" section (line 204), if the tool is `Eraser.id`, draw the live preview (`liveCanvas`) using `destination-out`.

## Risks & Notes
- This change brings the Eraser in line with the Brush tool's architecture.
- It automatically solves the selection constraint because the standard masking flow (`applySelectionMaskToCtx`) already handles `tempCtx`.
- The live preview logic in `renderLayers` will now correctly subtract the "erasure path" from the layer's pixels during the click-and-drag.

## Steps
1. [ ] Update `drawEraser` in `painting_tools.ts`.
2. [ ] Update MouseDown and Commit logic in `drawing_canvas.ts`.
3. [ ] Update `renderLayers` preview logic in `layers.ts`.
4. [ ] Test: Create a selection, use eraser across the border. Only pixels inside the selection should be erased.
