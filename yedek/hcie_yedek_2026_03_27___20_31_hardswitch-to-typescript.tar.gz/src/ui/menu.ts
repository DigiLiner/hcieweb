/**
 * @file menu.ts
 * @description Menu bar visibility and keyboard shortcut management.
 * Detects Tauri/Electron vs Web and shows/hides the HTML menu accordingly.
 * Migrated from menu.js.
 */

import { g } from '../core/globals';

declare global {
  interface Window {
    process?: { type?: string };
    newCanvas?: () => void;
    clearCanvas?: () => void;
    cutSelection?: () => void;
    copySelection?: () => void;
    pasteSelection?: () => void;
    duplicateSelection?: () => void;
    undoImage?: () => void;
    redoImage?: () => void;
    zoomIn?: () => void;
    zoomOut?: () => void;
    renderImageTabs?: () => void;
  }
}

// ─── Environment Detection ─────────────────────────────────

function isDesktopApp(): boolean {
  return (
    typeof window.__TAURI__ !== 'undefined' ||
    typeof window.electronAPI !== 'undefined' ||
    navigator.userAgent.toLowerCase().includes('electron')
  );
}

// ─── Menu Bar Initialization ───────────────────────────────

function initializeMenuBar(): void {
  const menuBar = document.getElementById('appMenuBar');
  if (!menuBar) {
    console.warn('Menu bar element not found');
    return;
  }

  if (isDesktopApp()) {
    // Hide web menu — native OS menu is used by Tauri/Electron
    menuBar.style.display = 'none';
    console.log('Running in Desktop mode — using native menu');
  } else {
    menuBar.style.display = 'table-row';
    console.log('Running in web mode — showing HTML menu');
  }
}

// ─── Keyboard Shortcuts ────────────────────────────────────

function handleKeyboardShortcut(e: KeyboardEvent): void {
  const menuBar = document.getElementById('appMenuBar');
  if (!menuBar || menuBar.style.display === 'none') return;

  const ctrl = e.ctrlKey || e.metaKey;
  const shift = e.shiftKey;

  if (ctrl && e.key === 'n') {
    e.preventDefault();
    window.newCanvas?.();
  } else if (ctrl && e.key === 'o') {
    e.preventDefault();
    (document.getElementById('btn-open') as HTMLButtonElement | null)?.click();
  } else if (ctrl && !shift && e.key === 's') {
    e.preventDefault();
    (document.getElementById('btn-save') as HTMLButtonElement | null)?.click();
  } else if (ctrl && !shift && e.key === 'x') {
    e.preventDefault();
    window.cutSelection?.();
  } else if (ctrl && !shift && e.key === 'c') {
    e.preventDefault();
    window.copySelection?.();
  } else if (ctrl && !shift && e.key === 'v') {
    e.preventDefault();
    window.pasteSelection?.();
  } else if (ctrl && !shift && e.key === 'j') {
    e.preventDefault();
    window.duplicateSelection?.();
  } else if (ctrl && e.key === 'z') {
    e.preventDefault();
    window.undoImage?.();
  } else if (ctrl && e.key === 'y') {
    e.preventDefault();
    window.redoImage?.();
  } else if (e.key === 'Delete') {
    e.preventDefault();
    window.clearCanvas?.();
  } else if (ctrl && (e.key === '+' || e.key === '=')) {
    e.preventDefault();
    window.zoomIn?.();
  } else if (ctrl && e.key === '-') {
    e.preventDefault();
    window.zoomOut?.();
  }
}

// ─── New Canvas Helper ─────────────────────────────────────

function newCanvas(): void {
  if (confirm('Create a new canvas? Unsaved changes will be lost.')) {
    window.clearCanvas?.();
    console.log('New canvas created');
  }
}

// ─── Initialization ────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  initializeMenuBar();
});

document.addEventListener('keydown', handleKeyboardShortcut);

// Expose helpers
window.newCanvas = newCanvas;

// Expose g for the tab/menu bar reference
void g; // prevent tree-shaking of import
