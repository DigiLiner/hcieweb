# 🚀 Quick Start - Localhost Development

## Run on Localhost (3 Options)

### ✨ Option 1: Webpack Dev Server (Best for Development)
```bash
npm run web:dev
```
**What it does:**
- Compiles TypeScript automatically
- Opens browser at `http://localhost:8080`
- Hot reload - changes appear instantly
- Shows errors in browser overlay

---

### 📄 Option 2: Simple HTTP Server
```bash
npm run build   # Compile TypeScript first
npm run serve   # Then serve at http://localhost:8000
```
**What it does:**
- Quick and simple
- No hot reload
- Manual browser refresh needed

---

### 💻 Option 3: Electron Desktop App
```bash
npm run dev
```
**What it does:**
- Runs as desktop application
- Uses Electron native features

---

## First Time Setup

```bash
cd /run/media/hc/DATA/00_PROJECTS/Electron/hcie
npm install
npm run web:dev
```

---

## Common Commands

| Command | What It Does |
|---------|-------------|
| `npm run web:dev` | Start localhost dev server (port 8080) |
| `npm run web:build` | Build production bundle |
| `npm run serve` | Simple HTTP server (port 8000) |
| `npm run build` | Compile TypeScript only |
| `npm run dev` | Run Electron desktop app |

---

## What Ports Are Used?

- **8080** - Webpack dev server (hot reload)
- **8000** - Simple HTTP server (manual refresh)

---

## Troubleshooting

**Port already in use?**
```bash
# Kill process on port 8080
killall -9 node
# Or change port in webpack.config.web.js
```

**Dependencies missing?**
```bash
npm install
```

**TypeScript errors?**
```bash
npm run build
```

---

## Next Steps

1. Run `npm run web:dev`
2. Browser opens automatically
3. Open DevTools (F12) to see console
4. Start coding - changes hot reload!

See [DEV_GUIDE.md](file:///run/media/hc/DATA/00_PROJECTS/Electron/hcie/DEV_GUIDE.md) for detailed documentation.
