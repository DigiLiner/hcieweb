# HCIE - Modern Image Editor with Classic Vibes

[![License: ISC](https://img.shields.io/badge/License-ISC-blue.svg)](https://opensource.org/licenses/ISC)
[![Platform: Electron](https://img.shields.io/badge/Platform-Electron-blueviolet.svg)](https://www.electronjs.org/)
[![Theme: Dark/Light](https://img.shields.io/badge/Theme-Dynamic-ff69b4.svg)](#features)

HCIE is a powerful, lightweight image editor that bridges the gap between classic design aesthetics and modern web performance. Built with Electron and TypeScript, it offers a seamless cross-platform experience with a focus on specialized algorithms and professional PSD support.

<img width="1078" height="825" alt="image" src="https://github.com/user-attachments/assets/ba2d0e00-c6c6-4315-ad86-9247988ffeca" />

Test page : https://digiliner.org/hcie/

## ✨ Features

-   **🎨 Dual-Core Rendering**: High-performance canvas logic with a fallback web mode for browser utilization.
-   **📁 Professional PSD Support**: 
    -   Full multi-layer PSD saving via `ag-psd`.
    -   Robust PSD loading and layer extraction using `psd.js`.
-   **📐 Advanced Vector Tools**:
    -   Rounded Rectangle tool with live corner radius control.
    -   Smart Vector Selection with real-time property synchronization.
-   **🎭 Specialized Filters**: Includes unique algorithms like *Melt*, *Shear*, and *Mosaic*, alongside standard Grayscale, Sepia, and Blur.
-   **🌙 Dynamic Theming**: Fully responsive system that respects OS `prefers-color-scheme` with manual toggle for Dark/Light modes.
-   **🖼️ Layer Management**: Comprehensive layer system with opacity control and visibility toggles.
-   **💬 Custom Dialogs**: Premium, non-blocking UI experience using a centralized `DialogHandler`.

## 🚀 Getting Started

### Prerequisites

-   [Node.js](https://nodejs.org/) (v16+)
-   npm

### Installation

1.  Clone the repository:
    ```bash
    git clone https://github.com/DigiLiner/hcie_electron.git
    cd hcie
    ```

2.  Install dependencies:
    ```bash
    npm install
    ```

3.  Build the core engine:
    ```bash
    npm run build:core
    ```

### Running the Application

-   **Electron App**:
    ```bash
    npm start
    ```
-   **Web Development Mode**:
    ```bash
    npm run web:dev
    ```

## 🏗️ Architecture

HCIE follows an **Orchestrator Pattern**:
-   **Core (`packages/core`)**: Contains the "Black Box" algorithms and low-level canvas logic.
-   **Renderer**: Manages UI state, event bus communication (e.g., `syncOpacity`), and user orchestration.
-   **Main**: Handles Electron-specific system integrations and file I/O.

## 🛠️ Project Scripts

-   `npm run start`: Launch the Electron application.
-   `npm run dev`: Build the core and start the main app workspace.
-   `npm run web:dev`: Start a Webpack development server for the web version.
-   `npm run app:dist`: Package the application for distribution using electron-builder.

## 📄 License

This project is licensed under the **ISC License**. See the `LICENSE` file for details.

---

*Part of the DigiLiner ecosystem. Designed for speed, built for creators.*
