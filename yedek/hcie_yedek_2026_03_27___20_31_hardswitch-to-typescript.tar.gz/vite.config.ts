import { defineConfig } from 'vite';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  // Single-page app — entry is index.html at root
  root: '.',
  publicDir: 'public',

  resolve: {
    alias: {
      '@core': resolve(__dirname, 'src/core'),
      '@canvas': resolve(__dirname, 'src/canvas'),
      '@tools': resolve(__dirname, 'src/tools'),
      '@ui': resolve(__dirname, 'src/ui'),
      '@io': resolve(__dirname, 'src/io'),
    },
  },

  build: {
    outDir: 'tauri-dist',
    emptyOutDir: true,
    sourcemap: true,
    rollupOptions: {
      input: resolve(__dirname, 'index.html'),
    },
  },

  server: {
    port: 1420,
    strictPort: true,
    // Prevent Vite from opening the browser — Tauri does it
    open: false,
  },
});
