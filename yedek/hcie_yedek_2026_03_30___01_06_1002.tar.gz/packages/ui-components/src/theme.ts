/**
 * Theme Manager
 * Handles manual theme toggling and persists the choice in localStorage.
 */

export function setupThemeToggle() {
    const themeBtn = document.getElementById('toggle-dark-mode');
    if (!themeBtn) {
        console.warn('Theme toggle button not found');
        return;
    }

    // Initialize theme based on preference or system
    const savedTheme = localStorage.getItem('hcie-theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);
        updateIconThemes(savedTheme);
    } else {
        // Default to automatic (managed by CSS media queries)
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        updateThemeIcon(isDark ? 'dark' : 'light');
        updateIconThemes(isDark ? 'dark' : 'light');
    }

    themeBtn.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        let newTheme: string;

        if (currentTheme === 'dark') {
            newTheme = 'light';
        } else if (currentTheme === 'light') {
            newTheme = 'dark';
        } else {
            // If currently automatic, we need to determine what it currently is
            const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            newTheme = isDark ? 'light' : 'dark';
        }

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('hcie-theme', newTheme);
        updateThemeIcon(newTheme);
        updateIconThemes(newTheme);
        
        console.log(`Theme manually set to: ${newTheme}`);
    });

    // Listen for system theme changes to update icon if in auto mode
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem('hcie-theme')) {
            const newTheme = e.matches ? 'dark' : 'light';
            updateThemeIcon(newTheme);
            updateIconThemes(newTheme);
        }
    });

    console.log('[THEME] Toggle initialized');
}

function updateThemeIcon(theme: string) {
    const themeBtn = document.getElementById('toggle-dark-mode');
    if (!themeBtn) return;

    if (theme === 'dark') {
        themeBtn.textContent = '🌙';
    } else {
        themeBtn.textContent = '☀️';
    }
}

/**
 * Updates all icon paths based on the active theme.
 */
function updateIconThemes(theme: string) {
    const isDark = theme === 'dark';
    const targetFolder = isDark ? 'ie_dark' : 'ie_color';
    const sourceFolder = isDark ? 'ie_color' : 'ie_dark';

    console.log(`[THEME] Updating icon paths to: ${targetFolder}`);

    const images = document.querySelectorAll('img');
    images.forEach(img => {
        const src = img.getAttribute('src');
        if (src && src.includes('resources/themes/')) {
            // This replacement handles both ie_color -> ie_dark and ie_dark -> ie_color
            // even if the initialization state varies.
            const newSrc = src.replace(/resources\/themes\/(ie_color|ie_dark)\//, `resources/themes/${targetFolder}/`);
            if (newSrc !== src) {
                img.setAttribute('src', newSrc);
            }
        }
    });
}
