import { g } from './globals';

const STORAGE_KEY = 'hcie_tool_settings';

/**
 * Persistable tool settings.
 * Add any new global properties here that should survive a reload.
 */
const PERSISTENT_KEYS = [
    'pen_width',
    'pen_opacity',
    'pen_blur',
    'pen_tip',
    'pen_angle',
    'brush_hardness',
    'brush_flow',
    'brush_spacing',
    'spray_radius',
    'spray_density',
    'cyclic_color',
    'cyclic_color_speed',
    'shape_fill',
    'round_rect_corner_radius',
    'wand_tolerance',
    'wand_all_layers',
    'fill_tolerance',
    'fill_all_layers',
    'text_size',
    'text_font'
];

/**
 * Saves current tool settings to localStorage.
 */
export function saveToolSettings() {
    const settings: Record<string, any> = {};
    PERSISTENT_KEYS.forEach(key => {
        (settings as any)[key] = (g as any)[key];
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    console.log("[CONFIG] Tool settings saved to localStorage");
}

/**
 * Loads tool settings from localStorage and applies them to global state g.
 */
export function loadToolSettings() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
        try {
            const settings = JSON.parse(saved);
            Object.keys(settings).forEach(key => {
                if (PERSISTENT_KEYS.includes(key)) {
                    (g as any)[key] = settings[key];
                }
            });
            console.log("[CONFIG] Tool settings restored from localStorage");
            
            // Dispatch event to notify UI components to refresh their values
            window.dispatchEvent(new CustomEvent('settingsRestored'));
        } catch (e) {
            console.error("[CONFIG] Failed to load settings:", e);
        }
    }
}
