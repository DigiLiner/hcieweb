import { defineConfig } from 'vite';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const isWeb = mode === 'web';

  return {
    // Relative base path is the most portable for varied deployment scenarios
    base: process.env.VITE_BASE_URL || './',
    
    // Single-page app — entry is index.html at root
    root: '.',
    publicDir: 'public',

    resolve: {
      alias: {
        '@hcie/core': resolve(__dirname, 'packages/core/src/index.ts'),
        '@hcie/shared': resolve(__dirname, 'packages/shared/src/index.ts'),
        '@hcie/tools': resolve(__dirname, 'packages/tools/src/index.ts'),
        '@hcie/io': resolve(__dirname, 'packages/io/src/index.ts'),
        '@hcie/canvas-ui': resolve(__dirname, 'packages/canvas-ui/src/index.ts'),
        '@hcie/ui-components': resolve(__dirname, 'packages/ui-components/src/index.ts'),
        // Fallback for core's circular dependencies on UI elements
        '../canvas': resolve(__dirname, 'packages/canvas-ui/src'),
      }
    },

    plugins: [
      {
        name: 'fix-mime-types',
        configureServer(server) {
          server.middlewares.use((req, res, next) => {
            if (req.url) {
              const urlPath = req.url.split('?')[0];
              if (urlPath.endsWith('.ts')) {
                 // Force correct MIME type for TS files to prevent video/mp2t errors on Linux
                 res.setHeader('Content-Type', 'application/javascript');
              }
            }
            next();
          });
        }
      }
    ],


    build: {
      outDir: isWeb ? 'dist-web' : 'tauri-dist',
      emptyOutDir: true,
      sourcemap: true,
      rollupOptions: {
        input: resolve(__dirname, 'index.html'),
      },
    },

    server: {
      port: 1420,
      strictPort: true,
      // Ensure 127.0.0.1 is used correctly
      host: '127.0.0.1', 
      open: false,
    },
  };
});
