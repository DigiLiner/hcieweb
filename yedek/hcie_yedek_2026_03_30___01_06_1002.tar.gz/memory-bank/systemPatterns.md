# System Patterns

## Orchestration & Core
- **Black Box Core**: `packages/core/src/` is read-only. Access via `@hcie/core` exports.
- **Orchestrator Pattern**: UI logic and tool coordination live in `apps/` or root, using Core as a service.

## Communication & State
- **Event-Driven UI**: Panels sync via `CustomEvent` (`syncOpacity`, `toolChanged`).
- **DialogHandler**: Centralized UI for prompts, alerts, and formatting to ensure premium feel.

## Performance & Rendering
- **Atomic Resize**: Central `resizeCanvas(w, h)` in `drawing_canvas.ts` ensures all layers and UI stay in sync.
## UI Aesthetics & Themes
- **Unified Monochromatic Icons**: Toolicons use a synchronized system of `grayscale(1) brightness(0) invert(var(--icon-invert))` to ensure a consistent, professional soft gray look in Dark Mode regardless of original SVG colors.
- **CSS Variable Driven Themes**: All themeable properties (bg-surface, bg-panel, icon-filter) adhere to central variables in `global.css`.

## Project Structure
- **Monorepo**: Logical separation into `@hcie/core`, `@hcie/tools`, `@hcie/ui`, `@hcie/io`, and `@hcie/shared`.
