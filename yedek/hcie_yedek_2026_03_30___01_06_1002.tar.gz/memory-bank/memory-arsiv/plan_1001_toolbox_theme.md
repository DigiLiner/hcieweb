# Plan #1001 – Toolbox Buttons Theme Compatibility

## Goal
Redesign toolbox button styles so they adapt to light/dark themes automatically.
SVG icons inside the buttons must also change color based on the active theme.

## Root Cause Analysis
Toolbox buttons likely have hardcoded background or `fill` colors (e.g., `background: white`),
overriding the theme CSS variables. SVG icons may also have hardcoded fill colors.

## Files to Investigate & Modify
- `packages/ui-components/src/styles/global.css` (or `panels.css`) — Toolbox button styles
- `packages/ui-components/src/styles/options-bar.css` — Options bar button styles
- `public/svgicons/*.svg` — SVG icon fill colors
- `index.html` — Toolbox button HTML structure

## Implementation Steps

1. **Audit current button CSS**:
   - Locate `.toolbox button`, `#toolbox button`, or similar selectors.
   - Remove any hardcoded `background: white` or `color: #000` declarations.

2. **Define CSS variables for button theming** in `global.css`:
   ```css
   :root {
     --btn-bg: #e8e8e8;
     --btn-bg-hover: #d0d0d0;
     --btn-bg-active: #bbb;
     --btn-border: #aaa;
     --btn-text: #222;
     --btn-icon-filter: none; /* no inversion for dark icons on light bg */
   }
   [data-theme="dark"] {
     --btn-bg: #3a3a3a;
     --btn-bg-hover: #4a4a4a;
     --btn-bg-active: #555;
     --btn-border: #555;
     --btn-text: #eee;
     --btn-icon-filter: invert(1); /* invert dark icons → white */
   }
   ```

3. **Update toolbox button styles** to use CSS variables:
   ```css
   #toolbox button {
     background: var(--btn-bg);
     border: 1px solid var(--btn-border);
     color: var(--btn-text);
     transition: background 0.15s ease;
   }
   #toolbox button:hover { background: var(--btn-bg-hover); }
   #toolbox button.active { background: var(--btn-bg-active); }
   #toolbox button img,
   #toolbox button svg { filter: var(--btn-icon-filter); }
   ```

4. **For SVG icons loaded as `<img>` tags**: Use CSS `filter: invert(1)` in dark mode.

5. **For inline SVG icons**: Set `fill: currentColor` inside SVGs and inherit from button's `color`.

6. **Test** toggle between light/dark themes and verify button + icon visibility in both modes.

## Risks & Notes
- The `filter: invert(1)` approach works well for monochromatic icons but may affect colorful icons.
  For colorful icons, separate light/dark SVG variants may be needed (see Task #1005).
- `@media (prefers-color-scheme: dark)` must also be covered in CSS if `data-theme` attribute is not set.

## Status
- [ ] Pending implementation
