# Plan #1008 & #1009 – AI Behavior Rules: Task Status Reporting & Confirmation

## Goal
These two tasks are about **AI agent behavior rules**, not code features:

### #1008 – Human-Readable, Colored Task Status File
After every task fix or action, fill `MESSAGE_FROM_AGENT.md` with current task statuses.
The file must be:
- Human readable
- Color-coded (using emoji as color indicators, since .md is plain text)
- Updated **always** after any significant change

### #1009 – Waiting-to-Confirm Rule
After fixing or completing a task, the agent must:
1. Mark that task as **🟡 Waiting to confirm** in `MESSAGE_FROM_AGENT.md`.
2. NOT take any further actions on that task until the USER explicitly confirms it.
3. Only then change the status to **🟢 Completed**.

## AGENTS.md Rule Updates Required

The following rules need to be added to `/home/hc/Belgeler/00_PROJECTS/Tauri/hcie/AGENTS.md`:

```markdown
## 5. Status Reporting (Updated with #1008 & #1009)

### MESSAGE_FROM_AGENT.md – Color-Coded Status Report
- Update `MESSAGE_FROM_AGENT.md` after EVERY significant task or change.
- The file MUST be human-readable with color-coded status indicators using emoji:
  - 🟡 **Waiting to confirm** – Task finished/fixed but not yet confirmed by user.
  - 🟢 **Completed** – Explicitly confirmed by the USER.
  - 🔴 **In Progress** – Currently being worked on.
  - ⚪ **Backlog** – Planned but not yet started.

### Waiting-to-Confirm Rule (#1009)
- After completing or fixing ANY task, immediately mark it as 🟡 in `MESSAGE_FROM_AGENT.md`.
- DO NOT take further actions on a 🟡 task until the USER confirms it.
- Only move to 🟢 Completed after receiving explicit USER confirmation.
```

## Implementation Steps

1. **Update `AGENTS.md`** with the rules above (Section 5 update).
2. **Establish `MESSAGE_FROM_AGENT.md` template**:

```markdown
# Task Status Report
*Last updated: [timestamp]*

## 🟢 Completed (USER confirmed)
- [List of confirmed-complete tasks]

## 🟡 Waiting to Confirm (finished, needs user verification)
- [List of tasks the agent has finished but not yet confirmed]

## 🔴 In Progress
- [List of currently active tasks]

## ⚪ Backlog
- [List of planned but not yet started tasks]
```

3. **Run a fresh update** to `MESSAGE_FROM_AGENT.md` using this template, reflecting current state.

## Notes
- This is a process/workflow change, not a code change.
- AGENTS.md is writable (it's not inside `packages/core/src/`).
- `USER_TASKS.md` must remain read-only for the agent.

## Status
- [x] Rules understood and followed (as of this planning session)
- [ ] AGENTS.md needs to be officially updated with written rules
- [ ] MESSAGE_FROM_AGENT.md template needs to be applied
