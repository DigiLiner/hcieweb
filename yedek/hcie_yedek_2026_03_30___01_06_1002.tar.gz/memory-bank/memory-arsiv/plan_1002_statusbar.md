# Plan #1002 – Status Bar Visibility in Web Version
- Status: Completed 🟢
- Task ID: #1002

## Goal
Ensure the status bar is visible in the web browser version of the application.

## Root Cause Analysis
The status bar may be:
- Hidden by a CSS rule specific to the Tauri environment (e.g., display:none for non-Tauri).
- Collapsed by a layout issue (e.g., `overflow: hidden`, `height: 0`, or flex layout problem).
- Not rendered because of a JS condition that checks for a Tauri API before showing the bar.

## Files to Investigate & Modify
- `index.html` — Status bar HTML element location
- `packages/ui-components/src/styles/global.css` (or `panels.css`) — Status bar CSS
- `packages/canvas-ui/src/drawing_canvas.ts` — Status bar update calls
- `packages/ui-components/src/UIController.ts` — Initialization, platform detection

## Implementation Steps

1. **Locate the status bar element** in `index.html` (search for `status-bar`, `statusbar`, or similar ID/class).

2. **Check if there's a Tauri-only guard** in JS:
   - Look for `if (window.__TAURI__)` or similar platform checks around status bar initialization.
   - Remove or relax those guards so the bar is always initialized.

3. **Audit CSS**:
   - Look for `display: none`, `visibility: hidden`, `height: 0`, or `overflow: hidden` on the status bar.
   - Ensure the status bar element has proper dimensions and is not crushed by flexbox.

4. **Fix layout if needed**:
   - Ensure the root layout (`body` or `#app`) uses `flex-direction: column` with the status bar as a fixed-height footer.
   - Use `flex-shrink: 0` on the status bar to prevent collapse.

5. **Test** in a plain browser (not Tauri) by running `npm run dev` and visiting `http://localhost:1420`.

## Risks & Notes
- Be careful not to break the Tauri layout when fixing the web layout.
- The status bar may show/hide zoom level, cursor coordinates, etc. — ensure those data sources work in web mode too.

## Status
- [x] Completed 🟢 (Confirmed 2026-03-30 01:02)
- [x] **Resolution**: Fixed structural DOM nesting errors (extra `</div>` tags) in the Right Sidebar that caused the `#appContainer` to close prematurely and hide the status bar. Increased bar height to 25px and improved contrast for better visibility.
