# Plan #1004 – Dark Theme Checkerboard Pattern

## Goal
When the dark theme is active, the transparency checkerboard background must use dark gray + medium gray squares (instead of the current white + light gray), matching the dark UI aesthetically.

## Files to Investigate & Modify
- `public/resources/` — Where checkerboard images/patterns are stored
- `packages/ui-components/src/styles/global.css` — CSS for canvas background
- `packages/canvas-ui/src/drawing_canvas.ts` — Canvas background rendering
- `packages/ui-components/src/theme.ts` — Theme change event source

## Implementation Strategy

### Option A: CSS-only (preferred — no image files)
Use CSS to generate the checkerboard pattern with a linear gradient and update it via CSS variables:

```css
:root {
  --checker-color-1: #c0c0c0;
  --checker-color-2: #808080;
}
[data-theme="dark"] {
  --checker-color-1: #404040;
  --checker-color-2: #2a2a2a;
}
.canvas-transparency-bg {
  background-image: linear-gradient(
      45deg,
      var(--checker-color-1) 25%,
      transparent 25%
    ),
    linear-gradient(
      -45deg,
      var(--checker-color-1) 25%,
      transparent 25%
    ),
    linear-gradient(45deg, transparent 75%, var(--checker-color-1) 75%),
    linear-gradient(-45deg, transparent 75%, var(--checker-color-1) 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0px;
  background-color: var(--checker-color-2);
}
```

### Option B: Separate SVG/PNG files per theme
- Create `checkerboard-light.svg` and `checkerboard-dark.svg` in `public/resources/`.
- Switch the CSS `background-image` URL using a CSS variable or JS on theme toggle.
- Less preferred — adds assets, harder to maintain.

## Implementation Steps

1. **Choose Option A (CSS-only)**.
2. Add `--checker-color-1` and `--checker-color-2` CSS variables to `:root` and `[data-theme="dark"]` in `global.css`.
3. Find the CSS selector that applies the canvas checkerboard background.
4. Replace any hardcoded checkerboard image/gradient with the variable-based version.
5. If the checkerboard is drawn on a `<canvas>` element (not CSS), update `drawing_canvas.ts` to read a CSS variable at draw time using `getComputedStyle(document.documentElement).getPropertyValue('--checker-color-1')`.
6. Hook into theme toggle event to redraw the checkerboard whenever the theme changes.
7. Test both themes visually.

## Risks & Notes
- If the canvas background is drawn programmatically (not CSS), the redraw must be triggered on theme change.
- Ensure that re-rendering the checkerboard doesn't affect the drawing layers.

## Status
- [ ] Pending implementation
