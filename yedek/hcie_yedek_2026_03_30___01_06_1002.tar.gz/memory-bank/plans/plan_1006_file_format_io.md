# Plan #1006 – Multi-Format Image I/O Infrastructure

## Goal
Design and implement an interface system for reading and writing multiple image file formats.
All format adapters must conform to a single `IImageFormat` interface, allowing plug-and-play support.

## Supported Formats (Phase 1)

### Standard Raster Formats (Browser-native via Canvas API)
- PNG, JPEG, GIF, BMP, WebP — via `canvas.toDataURL()` / `createImageBitmap()`

### Extended Formats (via FOSS libraries)
- **PSD** (Photoshop) — `ag-psd` library (already in `public/ag-psd.js`)
- **TGA** — `tga.js` or manual implementation
- **ICO** — `@nicolo-ribaudo/image-ico` or custom parser
- **GIF** — `gifuct-js` (for animated GIF reading)

### Application Formats (Phase 2 — future)
- Krita (.kra), GIMP (.xcf), Paint.NET (.pdn) — complex, requires research or external tools

## Architecture

### Interface Definition
```typescript
// packages/io/src/format-interface.ts (NEW)
export interface IImageFormat {
  readonly name: string;
  readonly extensions: string[];
  canRead: boolean;
  canWrite: boolean;
  read(buffer: ArrayBuffer): Promise<ImageData | ImageData[]>; // layers as array
  write(imageData: ImageData, options?: object): Promise<ArrayBuffer>;
}
```

### Format Registry
```typescript
// packages/io/src/format-registry.ts (NEW)
export class FormatRegistry {
  private formats: Map<string, IImageFormat> = new Map();
  register(format: IImageFormat): void;
  getByExtension(ext: string): IImageFormat | null;
  getAll(): IImageFormat[];
  getSaveFilter(): string; // "PNG Images|.png|JPEG Images|.jpg|..."
  getOpenFilter(): string;
}
```

### Individual Format Adapters
```
packages/io/src/formats/
├── png-format.ts         — Native canvas API
├── jpeg-format.ts        — Native canvas API
├── bmp-format.ts         — Canvas API
├── webp-format.ts        — Canvas API
├── psd-format.ts         — ag-psd (existing)
├── tga-format.ts         — Custom or library
├── ico-format.ts         — Custom parser
└── gif-format.ts         — gifuct-js for read, basic for write
```

## Files to Create/Modify

### [NEW] `packages/io/src/format-interface.ts`
- `IImageFormat` interface

### [NEW] `packages/io/src/format-registry.ts`
- `FormatRegistry` class with `register()`, `getByExtension()`, filter generators

### [NEW] `packages/io/src/formats/png-format.ts`
- Adapter using Canvas API `toBlob('image/png')` and `createImageBitmap()`

### [NEW] `packages/io/src/formats/jpeg-format.ts`
- Adapter using Canvas API `toBlob('image/jpeg')` with quality option

### [NEW] `packages/io/src/formats/psd-format.ts`
- Wrap existing `ag-psd` usage into the interface

### [MODIFY] `packages/io/src/index.ts`
- Export `FormatRegistry`, `IImageFormat`, and all adapters

### [MODIFY] `packages/io/src/project-io.ts`
- Replace direct format calls with `FormatRegistry.getByExtension()` for routing

## Implementation Steps

1. Create `format-interface.ts` with the `IImageFormat` type definition.
2. Create `format-registry.ts` with registration and lookup logic.
3. Implement PNG and JPEG adapters using Canvas API (no library needed).
4. Wrap existing `ag-psd` code into `psd-format.ts`.
5. Update `project-io.ts` to use the registry for open/save routing.
6. Export everything from `packages/io/src/index.ts`.
7. Test: open and save PNG, JPEG, PSD files from the UI.

## Phase 2 (Future)
- Integrate `gifuct-js` for animated GIF reading.
- Add TGA and ICO adapters.
- Research Krita/GIMP/Paint.NET format specs.

## Risks & Notes
- FOSS library compatibility: only use libraries that work offline (no CDN).
- `ag-psd` is already bundled — no additional dependencies needed for PSD.
- BMP support depends on browser; may need a small custom parser for edge cases.
- Keep complex format parsing in `packages/io/` only — do not pollute `@hcie/core`.

## Status
- [ ] Pending implementation
