# Progress

### Completed
- [x] Phase 4: Comprehensive TypeScript Migration & UI Modularization
    - [x] Migrated all UI components (`menu`, `panels`, `tabs`, etc.) to `src/ui/`.
    - [x] Consolidated global types into `src/env.d.ts`.
    - [x] Resolved strict TypeScript errors in `document.ts` and `layers.ts`.
    - [x] Task 4: Configure TypeScript project references and build chain
    - [x] Isolated document states to prevent cross-tab selection data leakage.
    - [x] Verified and fixed all syntax errors and broken imports across UI components.
    - [x] Updated `src/main.ts` as the central orchestrator.
- [x] Phase 5: Drawing Canvas Migration & Stabilization 
    - [x] Refactored `drawing_canvas.js` to `drawing_canvas.ts` with 100% type safety.
    - [x] Resolved illegal `offsetX/Y` property assignments using local coordinates.
    - [x] Implemented robust null-checking for all canvas contexts and DOM elements.
    - [x] Standardized tool interaction logic (Magic Wand, Flood Fill, Pen, Brush).
    - [x] Integrated marching ants animation with modular layer rendering.
    - [x] Wired history system (Undo/Redo) to the new architecture.
    - [x] Resolved all IDE-reported problems (redeclarations, implicit any, argument mismatches).
- [x] Phase 6: Project IO & Filter Migration
    - [x] Migrated `project_io.js` to `project-io.ts` with full type safety.
    - [x] Implemented unified cross-platform File API (`api.ts`) for Tauri/Web.
    - [x] Added `handleOpenFile` and `handleSaveFile` with support for `.hcie`, `.psd`, and standard image formats.
    - [x] Wired file operations to both the top menu and the toolbar buttons.
    - [x] Integrated `psd.js` and `ag-psd` for full PSD reading and writing support.
- [x] Phase 7: UI Modernization & Custom Window Decorations
    - [x] Transitioned to a frameless window (`decorations: false`) in Tauri config.
    - [x] Integrated custom window controls (Minimize, Maximize, Close) into the menu bar.
    - [x] Implemented a unified dragging region for the application header.
    - [x] **FIXED:** Corrected `appMenuBar` layout (changed `table-row` to `flex`) to restore visibility and interaction.
    - [x] **FIXED:** Added CSS `-webkit-app-region` properties for reliable native window dragging.
    - [x] **FIXED:** Added explicit Tauri v2 `core:window:default` permissions to enable window state control.
    - [x] **Artistic Brushes Panel:** Implemented a dynamic brush panel that appears only when the Brush tool is active, featuring Oil, Charcoal, Watercolor, Calligraphy, and Marker presets.
    - [x] **Cyclic Color (Rainbow) Mode:** Added a "Cyclic Color" toggle to Pen, Brush, and Spray tools.
        - [x] Colors now cycle through labels/hue automatically while drawing.
        - [x] Added a premium rainbow icon and checkbox to the Properties panel.
        - [x] Integrated `hslToHex` for smooth, high-quality transitions.
- [x] **Phase 8: Web Deployment Configuration**
    - [x] Updated `vite.config.ts` to support dual-target builds (`dist-web` vs `tauri-dist`) with `base: './'` for portability.
    - [x] Configured `package.json` with dedicated web scripts (`web:build`, `web:preview`, `web:serve`).
    - [x] Implemented platform-aware UI logic to hide Tauri-specific window controls in browser environments.
    - [x] Created and debugged GitHub Actions workflow (`deploy.yml`) for automated deployment.
    - [x] **FIXED:** Resolved 404 icon paths in `index.html` by migrating to theme-based resource paths.
- [ ] **Phase 9: UI/UX Polishing & Feature Implementation**
    - [ ] #1000: Fix Pen tool shapes theme contrast.
    - [ ] #1001: Redesign Toolbox buttons for theme compatibility.
    - [ ] #1002: Fix Status Bar visibility in Web version.
    - [ ] #1003: Implement Drawing tool settings persistence.
    - [ ] #1004: Update dark theme checkerboard pattern.
    - [ ] #1005: Reorganize SVG icons and resource structure.
    - [ ] #1006: Build Multi-format Image I/O infrastructure.
    - [ ] #1007: Constrain Floodfill to selection area.
    - [ ] #1008 & #1009: Standardize agent reporting and task confirmation.
- [x] **Phase 10: Monorepo Refactoring**
    - [x] Defined logical units: `@hcie/core`, `@hcie/tools`, `@hcie/ui-components`, `@hcie/canvas-ui`, `@hcie/io`, `@hcie/shared`.
    - [x] Initialized `packages/` directory structure.
    - [x] Configured `package.json` for all internal workspace packages.
    - [x] Configured TypeScript project references and build chain.
    - [x] **FIXED:** Resolved all cross-package import errors and Vite resolution issues (`@hcie/*` aliases).
    - [x] **FIXED:** Reconstructed missing `tooltip.ts` and cleaned up stale compiled assets from `src/` directories.
    - [x] **FIXED:** Standardized on extensionless imports in source files for seamless Vite development.

### Current Status
- Modern, type-safe ESM architecture is fully established.
- All core and UI modules are migrated to TypeScript.
- Custom title bar and unified menu system implemented for Tauri v2.
- The build pipeline (Vite/Tauri) is ready for production testing.
- Deployment to GitHub Pages is functional.
- Phase 9 is now active, focusing on visual polish and user-requested features.

### Completed Milestones

#### 🚀 Platform & Infrastructure
- **Tauri v2 Migration:** Initialized Tauri v2, removed Electron dependencies, and created a lean `build:tauri` pipeline.
- **Web Deployment:** Configured GitHub Actions for automated deployment to GitHub Pages.
- **Packaging:** Configured and validated production builds for **AppImage**, **.deb**, and **.rpm** (Linux).

#### 🛠️ Core Engine & Tooling
- **TypeScript Core:** Migrated all painting, vector, and selection logic to strict TypeScript.
- **Improved Vector Selection:** Precise hit-testing for all shapes (Circle, Ellipse, Line, Rect) and hover cursor feedback.
- **Selection System:** Implemented marching ants, move-selection, move-content, and polygon selection.
- **Vector Engine:** Completed vector circle/rect/line tools with proportional resizing and live property synchronization.
- **Creative Tools:** Added a "Cyclic Color" (rainbow) mode for Drawing tools.

#### 🎨 UI & UX
- **Custom Title Bar:** Implemented a unified header with native drag regions and theme-aware window controls.
- **Theme System:** Added automatic system-preference theme detection and manual toggle with persistence.
- **Properties Panel:** Unified tool settings into a context-aware sidebar.
- **New Image Dialog:** Refined preset selection and fixed orientation/color bugs.

## In Progress
- [ ] Investigate Polygon Selection tool bug (not moving/clearing).
- [ ] Phase 9 tasks (#1000 - #1009).
- [x] Phase 10: Monorepo Refactoring.
    - [x] Resolved module resolution and global window mismatches in `packages/tools/src/selection.ts`.
    - [x] Corrected package dependencies in `@hcie/tools`.
    - [x] Fixed all `@hcie/*` import resolution errors in Vite and TypeScript.
    - [x] Reconstructed missing components and stabilized the dev environment.

## Pending
- Performance: monitor compositing with many layers.
- Abstraction of the IO interface to further separate Web and Tauri logic.
