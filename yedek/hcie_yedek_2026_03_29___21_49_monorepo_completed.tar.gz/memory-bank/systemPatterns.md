# System Patterns

## Orchestration & Core
- **Black Box Core**: `packages/core/src/` is read-only. Access via `@hcie/core` exports.
- **Orchestrator Pattern**: UI logic and tool coordination live in `apps/` or root, using Core as a service.

## Communication & State
- **Event-Driven UI**: Panels sync via `CustomEvent` (`syncOpacity`, `toolChanged`).
- **DialogHandler**: Centralized UI for prompts, alerts, and formatting to ensure premium feel.

## Performance & Rendering
- **Atomic Resize**: Central `resizeCanvas(w, h)` in `drawing_canvas.ts` ensures all layers and UI stay in sync.
- **CSS Variable System**: Styles are driven by `:root` variables in `styles.css` for robust theme support.

## Project Structure
- **Monorepo**: Logical separation into `@hcie/core`, `@hcie/tools`, `@hcie/ui`, `@hcie/io`, and `@hcie/shared`.
