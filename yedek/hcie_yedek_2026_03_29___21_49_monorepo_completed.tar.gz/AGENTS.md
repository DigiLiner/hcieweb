# AI Agent Rules & Architecture Policy

## 1. Language & Documentation
- **All documentation must be written in English.** This includes memory-bank files, code comments in documentation, commit messages, and any generated reports or walkthroughs.
- Code-level comments (e.g., inline PHP/JS) may remain in Turkish for consistency with the existing codebase.

## 2. Core Library Protection (Strictly Read-Only)
- **STABLE LIBRARY:** The directory `packages/core/src/` is considered a stable, immutable library.
- **NO MODIFICATIONS:** You are strictly forbidden from modifying, refactoring, or deleting any files inside `packages/core/src/`.
- **INTERFACE ONLY:** Use `packages/core/dist/index.d.ts` as your ONLY reference for the core library. Treat `@hcie/core` as an external npm package.
- **REPORT BUGS:** If you suspect a bug within the core library, report it to the user instead of attempting to fix it yourself.

## 3. Orchestration & Implementation Role
- **YOUR ROLE:** You are a high-level **Orchestrator** and **UI Coordinator**. 
- **DEVELOPMENT AREA:** All new features, UI logic, and tool coordinations must be written in the `apps/` directory or at the root level.
- **TRANSFORMATIONS:** For scaling, rotation, or layer manipulation, create new coordination scripts in `apps/`. Use the existing canvas context without altering the core engine's source code.
- **LIBRARIES:** Use only Free and Open Source (FOSS) libraries that work offline.

## 4. Memory Bank & Context Management
- **MANDATORY LOGGING:** Every action, decision, analysis, and change MUST be logged in the `memory-bank/` directory.
- **VIRTUAL CONTEXT (SWAP):** Use the `memory-bank/task-logs/` directory as a "virtual context swap" area. Update these logs frequently to track granular, unfinished work.
- **PERSISTENT TRACKING:** Active or unfinished task logs MUST NOT be archived until the task is fully completed and confirmed by the USER.
- **ARCHIVE AUTHORIZATION (CRITICAL):** Agents are strictly forbidden from archiving, moving, or deleting any active or unfinished task logs, plans, or documentation sections without explicit, per-item confirmation from the USER.
- **ARCHIVE PRIVACY:** Agents MUST NOT read the `memory-bank/memory-arsiv/` directory. It is for user reference only.
- **COMPLETION CONFIRMATION:** Before archiving any task log or marking a task as completed in `progress.md`, the agent MUST ask the user for confirmation every single time.
- **PLAN MAINTENANCE:** Keep the `memory-bank/plans/` directory updated with current architectural designs or feature implementation plans, but do not archive them prematurely.

## 5. Status Reporting
- **MESSAGE_FROM_AGENT.md:** Update this file after EVERY significant task or change.
- **STATUS INDICATORS:**
    - **🟡 Waiting to confirm:** Tasks that are finished or fixed but pending user verification. Do not take further actions on these until confirmed.
    - **🟢 Completed:** Only for tasks explicitly confirmed by the USER.
- **NON-INTERACTION:** Use `MESSAGE_FROM_AGENT.md` as your primary reporting channel. Respect the read-only status of `USER_TASKS.md`.
