# Plan #1000 – Pen Tool Shapes Theme Compatibility

## Goal
Fix pen tip shapes (cursor/preview) invisibility in the light (white) theme.
When the pen tool is active, the cursor preview or shape outlines must be visible in **both** light and dark themes.

## Root Cause Analysis
The pen tip preview shapes are likely drawn with a hardcoded color (e.g., white or a fixed dark color) on the canvas overlay, causing them to be invisible against a matching background.

## Files to Investigate & Modify
- `packages/canvas-ui/src/drawing_canvas.ts` — Where pen cursor/preview is drawn
- `packages/ui-components/src/properties-panel.ts` — UI controls for pen tool
- `packages/ui-components/src/styles/global.css` — CSS variables for themes
- `packages/ui-components/src/theme.ts` — Theme detection logic

## Implementation Steps

1. **Identify the drawing code** for pen tip preview in `drawing_canvas.ts`.
   - Search for `pen`, `cursor`, `preview`, `drawTip`, `strokeStyle`, or related rendering calls.

2. **Determine the current theme** dynamically:
   - Read `document.documentElement.getAttribute('data-theme')` or check `localStorage.getItem('hcie-theme')`.
   - Also check `window.matchMedia('(prefers-color-scheme: dark)').matches` as fallback.

3. **Apply a theme-aware color** for the pen tip preview:
   - Dark theme → use a light/white color with a dark outline.
   - Light theme → use a dark/black color with a light outline.
   - **Recommended pattern**: Use a composite stroke:
     - Draw an outer stroke/shadow in the opposite color for contrast.
     - Draw an inner stroke in the theme-appropriate color.
   - This guarantees visibility on **any** background.

4. **Create a helper function** `getThemeAwareStroke()` in `drawing_canvas.ts`:
   ```typescript
   function getThemeAwareStroke(): { primary: string, outline: string } {
     const isDark = document.documentElement.getAttribute('data-theme') === 'dark'
       || (document.documentElement.getAttribute('data-theme') === null
         && window.matchMedia('(prefers-color-scheme: dark)').matches);
     return isDark
       ? { primary: '#ffffff', outline: '#000000' }
       : { primary: '#000000', outline: '#ffffff' };
   }
   ```

5. **Update all pen cursor/preview draw calls** to use this helper.

## Risks & Notes
- Must not break the dark-theme appearance.
- The composite stroke (inner + outer) approach is robust and does not depend on CSS variables being applied to canvas contexts.

## Status
- [ ] Pending implementation
