// This is the main entry point for the Application
import { loadToolSettings } from '@hcie/core';

// Load saved tool settings before UI components initialize
loadToolSettings();

import './styles/styles.css';
import './styles/menu.css';
import './styles/tabs.css';
import './styles/options-bar.css';
import './styles/panels.css';
import './styles/dialog_handler.css';

import '@hcie/core'; // Side-effect: globals
import '@hcie/core'; // Side-effect: history
import * as layersModule from '@hcie/canvas-ui';
import * as drawingCanvasModule from '@hcie/canvas-ui';
import * as vectorToolsModule from '@hcie/tools';
import * as selectionToolsModule from '@hcie/tools';
import * as clipboardToolsModule from '@hcie/tools';
import * as documentModule from '@hcie/core';
import * as menuModule from '@hcie/ui-components';
import * as panelsModule from '@hcie/ui-components';
import * as optionsBarModule from '@hcie/ui-components';
import * as propertiesPanelModule from '@hcie/ui-components';
import * as tabsModule from '@hcie/ui-components';
import * as dialogHandlerModule from '@hcie/ui-components';
import * as colorBoxModule from '@hcie/ui-components';
import * as paintingToolsModule from '@hcie/tools';
import * as sprayModule from '@hcie/tools';
import * as floodFillModule from '@hcie/tools';
import * as filtersModule from '@hcie/canvas-ui';
import * as textToolModule from '@hcie/tools';
import * as filterUIModule from '@hcie/ui-components';
import * as apiModule from '@hcie/io';
import * as projectIOModule from '@hcie/io';
import * as psdHandlerModule from '@hcie/io';
import * as menuHandlersModule from '@hcie/ui-components';
import { setupWindowControls } from './window_controls';
import { setupThemeToggle } from '@hcie/ui-components';
import { initializeArtisticBrushes } from '@hcie/ui-components';

// Temporarily re-expose exported variables to window to keep legacy modules functioning
console.log("[INIT] Exposing layersModule to window...");
Object.assign(window, layersModule);
console.log("[INIT] Exposing drawingCanvasModule to window...");
Object.assign(window, drawingCanvasModule);
console.log("[INIT] Exposing vectorToolsModule to window...");
Object.assign(window, vectorToolsModule);
console.log("[INIT] Exposing selectionToolsModule to window...");
Object.assign(window, selectionToolsModule);
console.log("[INIT] Exposing clipboardToolsModule to window...");
Object.assign(window, clipboardToolsModule);
console.log("[INIT] Exposing documentModule to window...");
Object.assign(window, documentModule);
console.log("[INIT] Exposing menuModule to window...");
Object.assign(window, menuModule);
console.log("[INIT] Exposing panelsModule to window...");
Object.assign(window, panelsModule);
console.log("[INIT] Exposing optionsBarModule to window...");
Object.assign(window, optionsBarModule);
console.log("[INIT] Exposing propertiesPanelModule to window...");
Object.assign(window, propertiesPanelModule);
console.log("[INIT] Exposing tabsModule to window...");
Object.assign(window, tabsModule);
console.log("[INIT] Exposing dialogHandlerModule to window...");
Object.assign(window, dialogHandlerModule);
console.log("[INIT] Exposing colorBoxModule to window...");
Object.assign(window, colorBoxModule);
console.log("[INIT] Exposing paintingToolsModule to window...");
Object.assign(window, paintingToolsModule);
console.log("[INIT] Exposing sprayModule to window...");
Object.assign(window, sprayModule);
console.log("[INIT] Exposing floodFillModule to window...");
Object.assign(window, floodFillModule);
console.log("[INIT] Exposing filtersModule to window...");
Object.assign(window, filtersModule);
console.log("[INIT] Exposing textToolModule to window...");
Object.assign(window, textToolModule);
console.log("[INIT] Exposing filterUIModule to window...");
Object.assign(window, filterUIModule);
console.log("[INIT] Exposing apiModule to window...");
Object.assign(window, apiModule);
console.log("[INIT] Exposing projectIOModule to window...");
Object.assign(window, projectIOModule);
console.log("[INIT] Exposing psdHandlerModule to window...");
Object.assign(window, psdHandlerModule);
console.log("[INIT] Exposing menuHandlersModule to window...");
Object.assign(window, menuHandlersModule);

// Perform specific initializations
if (typeof (window as any).initializeColorBox === 'function') {
    console.log("[INIT] Initializing ColorBox...");
    (window as any).initializeColorBox();
} else {
    console.error("[INIT] ERROR: initializeColorBox not found on window!");
}

if (typeof (window as any).initPanels === 'function') {
    console.log("[INIT] Initializing Panels...");
    (window as any).initPanels();
}

if (typeof (window as any).initializePropertiesPanel === 'function') {
    console.log("[INIT] Initializing Properties Panel...");
    (window as any).initializePropertiesPanel();
}

if (typeof (window as any).initializeMenuBar === 'function') {
    console.log("[INIT] Initializing Menu Bar...");
    (window as any).initializeMenuBar();
}

console.log("HCIE All Modules (Core, Tools, UI) Initialized via TS");

// Setup Custom Titlebar Controls
setupWindowControls();

// Setup Theme Toggle
setupThemeToggle();

// Initialize Artistic Brushes panel logic
initializeArtisticBrushes();
