# Active Context

## Current Focus
Phase 9: UI/UX Polishing & Feature Implementation. Addressing theme compatibility, tool settings persistence, and expanding file format support.

## Tasks from USER_TASKS.md
- **#1000 – Pen tool shapes theme compatibility:** Fix pen tip shapes (cursor/preview) invisibility in light theme.
- **#1001 – Toolbox buttons theme compatibility:** Redesign toolbox buttons to adapt to themes and update SVG icon colors.
- **#1002 – Status bar visibility:** Ensure the status bar is visible in all versions (web and desktop).
- **#1003 – Drawing tool settings persistence:** Store brush/pen/eraser settings (size, opacity, radius) in a global config and persist them.
- **#1004 – Checkerboard pattern:** Redefine the transparency checkerboard for dark theme using darker colors.
- **#1005 – Resource reorganization:** Organize resource files (SVG icons) and move unused assets to an archive.
- **#1006 – File format infrastructure:** Design an interface for multi-format image I/O support.
- **#1007 – Floodfill masking:** Ensure floodfill is limited by the current selection area.
- **#1008 & #1009 – AI Behavior Refinement:** Maintain a task status report and use yellow/green confirmation status for tasks.

## Recent Achievements
- **Monorepo Migration (Phase 10 - In Progress):**
    - Moved source code from `src/` to specialized packages in `packages/`:
        - `src/canvas/*` → `packages/canvas-ui/src/`
        - `src/tools/*` → `packages/tools/src/`
        - `src/ui/*` → `packages/ui-components/src/`
        - `src/io/*` → `packages/io/src/`
    - Created `index.ts` for each package as explicitly exported public APIs.
    - Updated `vite.config.ts` with `@hcie/*` package aliases.
    - Refactored `import` statements in `src/main.ts` and UI handlers to use `@hcie/*` package paths.
- **Web Deployment Configuration (Phase 8 Complete):**
    - Successfully deployed the live application to `https://digiliner.github.io/hcieweb/`.
    - Resolved GitHub Actions build errors by fixing the `package-lock.json` dependency.
    - Eliminated deployment conflicts by removing the raw static-file workflow.
    - Standardized `base: './'` and transitioned `index.html` to relative paths for universal hosting support.
    - Fixed massive 404 icon breaks by standardizing paths to `resources/themes/ie_color/`.
- **Tauri v2 Migration:** Successfully transitioned from Electron to Tauri v2.
    - Added support for **AppImage** bundle target for portable Linux distribution.
- **Theme Manager:** Implemented manual dark/light mode toggle with persistence.
- **Improved Vector Selection:** Hit-testing is now precise for all shapes (Circle, Ellipse, Line, Rect) and added hover feedback (pointer cursor).
- **TypeScript Migration (Phase 5 complete):** All core and UI modules are now 100% type-safe.
- **Custom Window Decorations:** Implemented a modern, frameless window with fully functional custom controls and dragging.
- **Vector & Selection Tool Stability:** Resolved ghosting, rasterization overlaps, and handle alignment issues. Marching ants and transformation handles are now robust.
- **Theme & UI Synchronization:** Centralized CSS variable system with full dark/light mode support and cross-panel event bus.
- **Unified File I/O:** Added cross-platform "Open" and "Save" functions in `menu-handlers.ts`. Uses Tauri system dialogs on desktop and standard browser protocols on web. Supports `.hcie` projects, `.psd` files (via `psd.js`), and standard images.
- **Creative Tools Enhancements:** Added a "Cyclic Color" (rainbow) mode for Pen, Brush, and Spray tools.

## Current Workspace
- **Core Library:** `@hcie/core` (packages/core/dist/index.d.ts)
- **App Entry:** `src/main.ts`
- **Frontend Assets:** `index.html`, `src/styles/`

## Active Issues
1. **Polygon Selection Tool:** Reported as not working (not moving, not clearing). Requires Investigation.
2. **Floodfill Selection Constraint (#1007):** Needs confirmation if the current fix is sufficient.
3. **Theme Inconsistencies:** New tasks #1000, #1001, #1004 focus on visual issues in specific themes.

## Next Steps
- [ ] Complete import refactoring across all packages (automated `sed` migration pending verification).
- [ ] Address `packages/core/src/` read-only constraint for import path fixes.
- [ ] Validate monorepo build with `npx tsc -b`.
- [ ] Investigate and fix Polygon Selection tool issues.
- [ ] Implement Task #1000: Fix pen tip shapes contrast for light theme.
