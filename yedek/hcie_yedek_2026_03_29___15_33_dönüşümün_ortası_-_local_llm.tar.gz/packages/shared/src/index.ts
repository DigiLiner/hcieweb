/**
 * Shared constants and types for @hcie packages.
 */
export const VERSION = '0.0.0';
